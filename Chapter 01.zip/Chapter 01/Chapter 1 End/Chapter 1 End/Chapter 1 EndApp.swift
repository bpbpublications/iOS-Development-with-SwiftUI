//
//  Chapter_1_EndApp.swift
//  Chapter_1_End
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_1_EndApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
