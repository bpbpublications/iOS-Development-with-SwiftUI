//
//  ContentView.swift
//  Chapter_1_End
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct ContentView: View {
    @State private var isText = true
    var body: some View {
        Button{
            isText.toggle()
        }label:{
            shapeOrText()
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
// Group
extension ContentView{
    func shapeOrText() -> some View{
        Group{
            if isText {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.orange)
                    .frame(width: 100, height: 100)
            }else {
                Text("SwiftUI")
                    .font(.largeTitle)
            }

        }
    }

}

// AnyView
//extension ContentView{
//    func shapeOrText() -> some View{
//        if isText {
//            return AnyView(RoundedRectangle(cornerRadius: 10)
//                            .fill(Color.orange)
//                            .frame(width: 100, height: 100))
//        }else {
//            return AnyView(Text("SwiftUI")
//                            .font(.largeTitle))
//        }
//
//    }
//}

// @ViewBuilder

//extension ContentView{
//    @ViewBuilder
//    func shapeOrText() -> some View{
//        if isText {
//            RoundedRectangle(cornerRadius: 10)
//                .fill(Color.orange)
//                .frame(width: 100, height: 100)
//        }else
//        {
//            Text("SwiftUI")
//                .font(.largeTitle)
//        }
//    }
//}
