//
//  ContentView.swift
//  Chapter_1
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Understanding SwiftUI")
                .foregroundColor(.blue)
                .background(Color.red)
                .font(.largeTitle)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
