//
//  Chapter_1_1App.swift
//  Chapter_1_1
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_1_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
