//
//  AnatomyofaSwiftUIprojectsApp.swift
//  AnatomyofaSwiftUIprojects
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@main
struct AnatomyofaSwiftUIprojectsApp: App {
    init() {
        print("Empty_ProjectApp application starting point")
    }
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView()
        }.onChange(of: scenePhase) { phase in
            switch phase {
            case .background:
                print("App is in Background")
            case .inactive:
                print("App is inactive")
            case .active:
                print("App is active")
            @unknown default:
                print("default")
            }
        }
    }
}
