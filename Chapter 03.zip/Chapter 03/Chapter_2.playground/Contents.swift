import UIKit

var greeting = "Hello, playground"

//-------Constant

let myFullName = "Mukesh Sharma"
let height = 5.5
let numOfRow = 5
// String”
               // Int
// Double

//let myFullName : String = "Mukesh Sharma"   // String”

// Variables

var userCount = 10
var myAge = 34

//Comments

// your code

/*
if(statement){
}else {
}
*/

// Integers

let numberOfPages: Int = 10
print(numberOfPages)
let numberOfChapters = 3
print(numberOfChapters)

let numberOfPeople: UInt = 20
print(numberOfPeople)
let volumeAdjustment: Int32 = -1000
print(volumeAdjustment)

//Floating-point numbers

var d1 = 1.1
print(d1)
let d2: Double = 1.1
print(d2)
var d3 : Float = 3.14
print(d3)
d3 = Float(d1)
print(d3)

// Booleans
var seaIsRed = false
var isSalesman : Bool = true
if seaIsRed {
    print("Transport did not denied the sale")
} else {
    print("Transport denied the sale.")
}

if !seaIsRed { // its change the seaIsRed value false to true
    print("Transport denied the sale")
} else {
    print("Transport did  not denied the sale.")
}
//  String
let firstName = "Mukesh"
let lastName = "Sharma"
var strName = "My name is \(firstName) \(lastName)"
print(strName)

//Characters
let stringTemp = "Hello"
for c: Character in stringTemp {
    print("’\(c)’")
}

//Tuples

var salesManCode = ("PTL",1008, "QER")
let (Raman, Mike, April) = salesManCode
print(Raman)
print(Mike)
print(April)

print(salesManCode.0)
print(salesManCode.1)
print(salesManCode.2)

let https200Status = (statusCode: 200, description: "Working OK")
print(https200Status.statusCode)
print(https200Status.description)

// Arrays

var osList = [String]()
osList = ["iOS", "Android", "Windows Phone","Android"]
print(osList)
var item = osList[0]
print(item)

//Inserting elements into an array
osList.insert("iPad OS", at: 3)
print(osList)

//Modifying elements in an array
osList[1] = "BlackBerry"
print(osList)
// Appending elements in array
osList.append("New MAC OS")
print(osList)

osList += ["New MAC OS"]
print(osList)

//Removing elements from an array

osList.remove(at: 2)
print(osList)

osList.removeLast()
print(osList)

 osList.removeFirst()
print(osList)

osList.removeAll()
print(osList)


//Dictionaries

var platforms: Dictionary<String, String> = [
    "Apple": "iPhone",
    "Google" : "Pixel",
    "Microsoft" : "HTC Phone"
]

print(platforms)

//Retrieving elements from a dictionary

print(platforms["Google"]!)

//Modifying elementes
platforms["Google"] = "Android One"
print(platforms)

platforms.updateValue("Android One", forKey: "Google")
print(platforms)

//Removing an item from a dictionary

platforms["Google"] = nil
print(platforms)
platforms.removeValue(forKey:"Google")
print(platforms)


//Optional type
var errorCodeString : String?
errorCodeString  = "404"

if errorCodeString != nil {
   print("errorCodeString variable has a value assigned to it")
} else {
    print("errorCodeString variable has no value assigned to it")
}


if errorCodeString != nil {
    print(errorCodeString!)
}
 // Working with implicitly unwrapped optionals
var str: String! = "This is a string"
print(str)
str = nil
print(str)

//Using optional binding

var product : String? = "Pen"
if let temp = product {
    print("We have a product: \(temp)")
}
else{
    print("We do not have a product")
}

// Optional chaining

var product0 : String? = "Pen"
var product1 : String? = "Copy"
var product2 : String?  //= “Eraser”
var product3 : String? = "Past"
if let temp = product0, let temp1 = product1, let temp2 = product2, let temp3 = product3 {
    print("We have a product: \(temp)")
    print("We have a product: \(temp1)")
    print("We have a product: \(temp2)")
    print("We have a product: \(temp3)")
}else{
    print("We do not  have a  product")
}

// The Switch statement
var speed = 299792458
switch speed {
 case 299792458:
    print("Speed of light")
    case 343:
        print("Speed of sound")
    default:
        print("Unknown speed")
}

// ------
if speed == 299792458
{
    print("Speed of light")
}else if speed == 343
{
    print("Speed of sound")
}else
{
    print("Unknown speed")
}


//for-in loop

for index in 1...5 {
    print(index)
}

 osList = ["iOS", "Android", "Windows Phone", "Android"]
for os in osList
{
print(os)
    
}


// while loop
var index = 1
while index <= 10 {
   print( "Table of 2 \(2*index)")
   index = index + 1
}

// break
index = 1
      while index <= 10 {
         print( "Table of 2 is \(2*index)")
          if index == 5{
break }
         index = index + 1
}

// continue
index = 0
      repeat {
         index = index + 1
         if( index == 5 ){
continue }
         print( "Table of index is \(2*index)")
      } while index < 10


// Closures

//Creating a closure


var cosy = { () -> Void in
    print("Hello World")
}

cosy()
 var cosy1 = { (name: String) -> Void in
    print("Hello \(name)")
}

cosy1("Mike")

let cosy2 = { (name: String) -> String in
    return "Hello \(name)"
}

var message = cosy2("Mikoo")
print(message)

// Hello Mikoo

func closurePeram(handler: (String) -> Void) {
    handler("Welcome ")
}

closurePeram(handler: cosy1)


//closures with arrays

let peoples = ["Mike", "Raman", "April","Jon"]
peoples.map { name in
    print("Hello \(name)")
}

peoples.map {
   print("Hello \($0)")
}
