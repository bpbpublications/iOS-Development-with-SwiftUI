//
//  AlertModifierApp.swift
//  AlertModifier
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@main
struct AlertModifierApp: App {
    var body: some Scene {
        WindowGroup {
            AlertView()
        }
    }
}
