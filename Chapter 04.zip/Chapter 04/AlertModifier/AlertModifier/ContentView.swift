//
//  ContentView.swift
//  AlertModifier
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct AlertView: View {
    @State private var showingAlert = false
    var body: some View {
        Button(action: {
            self.showingAlert = true
        }){
            Text("Show Alert")
        }
        .alert(isPresented: $showingAlert) {
            Alert(
                title: Text("Are you sure?"),
                message: Text("Do you want to dismiss the view?"),
                primaryButton: .destructive(Text("Yes"), action: {
                    print("Yes clicked")}),
                secondaryButton: .cancel(Text("No"), action: {
                    print("Cancel clicked")})
            )
        } }
}

struct AlertView_Previews: PreviewProvider {
    static var previews: some View {
        AlertView()
    }
}
