//
//  ContaxtMenuApp.swift
//  ContaxtMenu
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@main
struct ContaxtMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
