//
//  ContentView.swift
//  DisclosureGroupEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        DisclosureGroup("Animals") {
            Text("Cat")
            Text("Dog")
            Text("Lion")
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
