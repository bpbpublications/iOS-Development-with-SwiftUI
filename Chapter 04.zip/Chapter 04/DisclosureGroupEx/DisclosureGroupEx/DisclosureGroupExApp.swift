//
//  DisclosureGroupExApp.swift
//  DisclosureGroupEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@main
struct DisclosureGroupExApp: App {
    var body: some Scene {
        WindowGroup {
            DisclosureGroupExpend()
        }
    }
}
