//
//  DisclosureGroupScrollView.swift
//  DisclosureGroupEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct DisclosureGroupScrollView: View {
    var body: some View {
        ScrollView{
            VStack(spacing: 20) {
                ForEach(0..<10){ _ in
                    DisclosureGroup("Information") {
                        GroupBox(label: Text("programming")) {
                            HStack{
                                Image("arrow_1")
                                Text("Understanding with SwiftUI")
                            }
                        } }
                } }
        }
    }
}

struct DisclosureGroupScrollView_Previews: PreviewProvider {
    static var previews: some View {
        DisclosureGroupScrollView()
    }
}
