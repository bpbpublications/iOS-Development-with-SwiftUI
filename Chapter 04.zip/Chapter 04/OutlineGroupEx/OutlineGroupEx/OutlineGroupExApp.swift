//
//  OutlineGroupExApp.swift
//  OutlineGroupEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@main
struct OutlineGroupExApp: App {
    var body: some Scene {
        WindowGroup {
            OutlineGroupDemo(items: Item.stubs)
        }
    }
}
