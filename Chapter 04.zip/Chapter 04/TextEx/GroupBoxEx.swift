//
//  GroupBoxEx.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct GroupBoxEx: View {
    var body: some View {
        
        GroupBox(label: Text("Information")) {
                    HStack{
                    Image("arrow_1")
                    Text("Understanding with SwiftUI")
                    }
            
        }

    }
}

struct GroupBoxEx_Previews: PreviewProvider {
    static var previews: some View {
        GroupBoxEx()
    }
}
