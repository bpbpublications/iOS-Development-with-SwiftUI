//
//  HorizontalScrollView.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct HorizontalScrollView: View {
    var body: some View {
        VStack {
            ScrollView(.horizontal){
            } }
        HStack(spacing: 10) {
            ForEach(0..<10) { index in
                ZStack {
                    Circle()
                        .fill(Color.red)
                        .frame(width: 70, height: 70)
                    Text("Item \(index)")
                } }
        }.padding()
    }
}


struct HorizontalScrollView_Previews: PreviewProvider {
    static var previews: some View {
        HorizontalScrollView()
    }
}
