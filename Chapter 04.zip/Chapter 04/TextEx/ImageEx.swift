//
//  ImageEx.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct ImageEx: View {
    var body: some View {
        HStack{
        Text("Hello, World!")
                .font(.largeTitle)
                .background(Color.orange)
                .foregroundColor(Color.white)
                .frame(width: 100)
                .lineLimit(2)
                 Image("Why")
        }
        
        HStack{
        Text("Hello, World!")
                .font(.largeTitle)
                .background(Color.orange)
                .foregroundColor(Color.white)
                .frame(width: 100)
                .lineLimit(2)
                 Image("Why")
                //.resizable()
                .frame(width: 60, height: 60)
        }
        
        Image(systemName:"star")
                    .resizable()
                   .frame(width: 60, height: 60)
                   .background(Color(.blue))
                   .foregroundColor(.red)
                   //.cornerRadius(60/2)
                   .clipShape(Circle())
    }
}

struct ImageEx_Previews: PreviewProvider {
    static var previews: some View {
        ImageEx()
    }
}

    

