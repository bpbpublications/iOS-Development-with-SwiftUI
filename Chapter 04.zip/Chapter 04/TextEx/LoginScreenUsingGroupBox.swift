//
//  LoginScreenUsingGroupBox.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct LoginScreenUsingGroupBox: View {
    
        @State var userName : String = ""
        @State var password : String = ""
        var body: some View {
            GroupBox(label: Text("Login").foregroundColor(Color.red)) {
                VStack(alignment: .center ){
                    TextField("Username", text: $userName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.all,4)
                    SecureField("Password",text: $password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.all,4)
                    Button(action: {}){
                        Image(systemName : "forward.fill")
                            .foregroundColor(.black)
                            .frame(width: 30, height:30, alignment: .center)
                            .padding(10)
                            .cornerRadius(10)
                            .background(Color(.green))
                    }
                    
                }
            }
            
        }
    }
    




struct LoginScreenUsingGroupBox_Previews: PreviewProvider {
    static var previews: some View {
        LoginScreenUsingGroupBox()
    }
}
