//
//  ScrollViewEx.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct ScrollViewEx: View {
    var body: some View {
        VStack {
            ScrollView {
                VStack(spacing: 10) {
                    ForEach(0..<10) { index in
                        ZStack {
                            Circle()
                                .fill(Color.red)
                                .frame(width: 70, height: 70)
                            Text("Item \(index)")
                        }
                    }
                }.padding()
            } }
    }
}

struct ScrollViewEx_Previews: PreviewProvider {
    static var previews: some View {
        ScrollViewEx()
    }
}
