//
//  ScrollViewReader.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct ScrollViewReaderEx: View {
    var body: some View {
        ScrollView {
            ScrollViewReader{ value in
                Button("Jump to row no 5") {
                    withAnimation {
                    value.scrollTo(5)
                    }
                }
                VStack(spacing: 10) {
                    ForEach(0..<20) { index in
                        ZStack {
                            Circle()
                                .fill(Color.red)
                                .frame(width: 70, height: 70)
                                .id(index)
                            Text("Item \(index)")
                        } }
                }
            }.padding()
        }
    }
}

struct ScrollViewReaderEx_Previews: PreviewProvider {
    static var previews: some View {
        ScrollViewReaderEx()
    }
}
