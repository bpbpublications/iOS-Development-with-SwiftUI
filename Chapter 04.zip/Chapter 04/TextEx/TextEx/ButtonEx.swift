//
//  ButtonEx.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct ButtonEx: View {
    var body: some View {
        
        VStack{
        Button("Plain", action: {
                        print("Button clicked")
                    }).buttonStyle(PlainButtonStyle())
        
      //  Customizing the button
        Button(action: {
                        print("Share tapped!")
                   }) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.title)
                    Text("Share")
                        .fontWeight(.semibold)
                        .font(.title)
                   }
                    .frame(width: 150, height: 100, alignment: .center)
        
        Button(action: {
                        print("Share tapped!")
                   }) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.title)
                         Text("Share")
                        .fontWeight(.semibold)
                        .font(.title)
                   }
                    .frame(width: 200, height: 85, alignment: .center)
                    .foregroundColor(.white)
        .background(LinearGradient(gradient: Gradient(colors: [.green, .orange]), startPoint: .leading, endPoint:. trailing))
                    .cornerRadius(40)
            
            // Action
            Button("Button title") {
                            print("Button Action!")
                        }
          //  Assigning a role
            Button("Delete", role: .destructive) {
                        print("Perform delete")
            }
        }
        
        
    }
    
}

struct ButtonEx_Previews: PreviewProvider {
    static var previews: some View {
        ButtonEx()
    }
}
