//
//  ContentView.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
                .font(.largeTitle)
                .background(Color.orange)
                .foregroundColor(Color.white)
        
        Text("Hello, World!")
                .font(.largeTitle)
                .background(Color.orange)
                .foregroundColor(Color.white)
                .frame(width: 100)
                .lineLimit(2)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
