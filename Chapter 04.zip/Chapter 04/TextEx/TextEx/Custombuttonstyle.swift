//
//  Custombuttonstyle.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI
@available(iOS 15.0, *)
struct Custombuttonstyle: View {
    var body: some View {
            Button("Tap On") {
                print("Button pressed!")
            }
            .buttonStyle(BlueButton())
        }

}

struct BlueButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .background(Color(red: 0.2, green: 0.4, blue: 0.0))
            .foregroundColor(.white)
            .clipShape(Circle())
} }
struct Custombuttonstyle_Previews: PreviewProvider {
    static var previews: some View {
        Custombuttonstyle()
    }
}
