//
//  SliderEx.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct SliderEx: View {
    @State var sliderValue: Double = 0
    var body: some View {
        VStack {
            Slider(value: $sliderValue, in: 0...20)
                .accentColor(Color.green)
                 .border(Color.green, width: 2)
            Text("Current slider value: \(sliderValue, specifier: "%.2f")")
        }.padding()
    }
    
}

struct SliderEx_Previews: PreviewProvider {
    static var previews: some View {
        SliderEx()
    }
}
