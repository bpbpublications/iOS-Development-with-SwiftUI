//
//  StepperEx.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct StepperEx: View {
    @State var stepperValue: Int = 0
    var body: some View {
        VStack {
            Stepper("Stepper value: \(stepperValue)", value: $stepperValue)
        }.padding()
    }
}


struct StepperEx_Previews: PreviewProvider {
    static var previews: some View {
        StepperEx()
    }
}
