//
//  TextExApp.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@main
struct TextExApp: App {
    var body: some Scene {
        WindowGroup {
            ScrollViewReaderEx()
        }
    }
}
