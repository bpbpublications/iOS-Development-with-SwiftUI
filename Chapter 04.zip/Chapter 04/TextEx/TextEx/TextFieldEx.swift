//
//  TextFieldEx.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct TextFieldEx: View {
    @State private var name: String = ""
    var body: some View {
        VStack {
            TextField("Enter your name", text: $name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            Text("Hello, \(name)!")
                
        }
        
    }
}


struct TextFieldEx_Previews: PreviewProvider {
    static var previews: some View {
        TextFieldEx()
    }
}
