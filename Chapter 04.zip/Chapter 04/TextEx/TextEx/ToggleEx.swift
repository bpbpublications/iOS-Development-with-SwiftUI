//
//  ToggleEx.swift
//  TextEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@available(iOS 15.0, *)
struct ToggleEx: View {
    @State private var isOn = false
    var body: some View {
        Toggle("Toggle", isOn: $isOn)
            .toggleStyle(.button)
            .tint(.purple)
    }
}

//struct ToggleEx: View {
//    @State var isSoundOn: Bool = true
//    var body: some View {
//        VStack {
//            Toggle(isOn: $isSoundOn) {
//                Text("MUSIC")
//            }
//            Image(systemName: isSoundOn ? "speaker.1.fill" : "speaker. slash.fill")
//                .font(.system(size: 56))
//                .padding()
//            Spacer()
//        }.padding()
//    }
//}

struct ToggleEx_Previews: PreviewProvider {
    static var previews: some View {
        ToggleEx()
    }
}
