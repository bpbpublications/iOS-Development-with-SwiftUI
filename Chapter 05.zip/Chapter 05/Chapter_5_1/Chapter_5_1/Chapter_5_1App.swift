//
//  Chapter_5_1App.swift
//  Chapter_5_1
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_5_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
