//
//  ContentView.swift
//  Chapter_5_1
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@propertyWrapper struct AllLowerCase {
    var wrappedValue: String {
        didSet {
            wrappedValue = wrappedValue.lowercased()
        }
        
    }
    init(wrappedValue: String) {
        self.wrappedValue = wrappedValue.lowercased()
    }
    
}

@propertyWrapper struct Capitalized {
    var wrappedValue: String {
        didSet { wrappedValue = wrappedValue.capitalized
            
        }
    }
    init(wrappedValue: String) {
        self.wrappedValue = wrappedValue.capitalized
    }
    
}

struct User {
    @Capitalized var userName: String
    @AllLowerCase var email: String
}

struct ContentView: View {
    var user = User(userName: "mukesh",
                            email: "Mukesh@gmail.com")
        var body: some View {
                Text(user.userName)
         Text(user.email)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
