//
//  Chapter_5_Access_environmentApp.swift
//  Chapter_5_Access_environment
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_5_Access_environmentApp: App {
    var body: some Scene {
        WindowGroup {
            AccessingEnvironment()
        }
    }
}
