//
//  ContentView.swift
//  Chapter_5_Access_environment
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct AccessingEnvironment: View {
    @Environment(\.colorScheme) private var colorScheme
       var body: some View {
           Text(colorScheme == .dark ? "Dark Mode" : "Light Mode")
               .foregroundColor(colorScheme == .dark ? .red : .blue)
       }
    
}


struct AccessingEnvironment_Previews: PreviewProvider {
    static var previews: some View {
        AccessingEnvironment()
    }
}
