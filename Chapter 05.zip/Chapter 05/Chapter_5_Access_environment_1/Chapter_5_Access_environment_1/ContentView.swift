//
//  ContentView.swift
//  Chapter_5_Access_environment_1
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct AccessingEnvironment: View {
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.calendar) private var calendar
    @Environment(\.locale) private var locale
   @Environment(\.timeZone) private var timezone
  var body: some View {
        Text(colorScheme == .dark ? "Dark Mode" : "Light Mode")
            .foregroundColor(colorScheme == .dark ? .red : .blue)
        Text(calendar.description)
        Text(locale.description)
        Text(timezone.description)
} }

struct AccessingEnvironment_Previews: PreviewProvider {
    static var previews: some View {
        AccessingEnvironment()
    }
}
