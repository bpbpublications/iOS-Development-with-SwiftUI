//
//  Chapter_5_Access_environment_2App.swift
//  Chapter_5_Access_environment_2
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_5_Access_environment_2App: App {
    var body: some Scene {
        WindowGroup {
            AccessingEnvironment()
        }
    }
}
