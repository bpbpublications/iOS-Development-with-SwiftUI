//
//  ContentView.swift
//  Chapter_5_Access_environment_2
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct AccessingEnvironment: View {
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    var body: some View {
        if verticalSizeClass == .regular {
            HStack {
                Text("Amar")
                Text("Akbar")
                Text("Anthony")
            }
            .font(.headline)
        } else {
            VStack {
                Text("Amar")
                Text("Akbar")
                Text("Anthony")
            }
            .font(.headline)
        }
} }

struct AccessingEnvironment_Previews: PreviewProvider {
    static var previews: some View {
        AccessingEnvironment()
    }
}
