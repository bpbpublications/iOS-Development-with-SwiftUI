//
//  ContentView.swift
//  Chapter_5_Access_environment_3
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI
struct AppCountryEnvironmentKey: EnvironmentKey {
    static var defaultValue: String = "India"
}
struct AppCountryCodeEnvironmentKey: EnvironmentKey {
static var defaultValue:Int = 91
}

struct CountryDetail: View {
    @Environment(\.countryName) private var countryName
    @Environment(\.countryCode) private var countryCode
       var body: some View {
           Text(countryName)
           Text(String(countryCode))
   }
   }
extension EnvironmentValues {
    var countryName : String {
      set { self[AppCountryEnvironmentKey.self] = newValue }
      get { self[AppCountryEnvironmentKey.self] }
    }
    var countryCode : Int {
      set { self[AppCountryCodeEnvironmentKey.self] = newValue }
      get { self[AppCountryCodeEnvironmentKey.self] }
} }
struct CountryDetail_Previews: PreviewProvider {
    static var previews: some View {
        CountryDetail()
    }
}
