//
//  Chapter_5_BindingApp.swift
//  Chapter_5_Binding
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_5_BindingApp: App {
    var body: some Scene {
        WindowGroup {
            BindingExample()
        }
    }
}
