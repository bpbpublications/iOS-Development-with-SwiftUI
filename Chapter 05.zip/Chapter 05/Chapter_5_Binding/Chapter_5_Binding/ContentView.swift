//
//  ContentView.swift
//  Chapter_5_Binding
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct BindingExample: View {
    @State private  var displayTokenView = false
        @State private  var bkgColor : Color = .red
        var body: some View {
            VStack{
                Button(action: {
                    self.displayTokenView = true
                }) {
                    Text("Display Token")
                        .background(bkgColor)
                        .foregroundColor(Color.white)
                }
                // Working with state
//                .sheet(isPresented: self.$displayTokenView) {
//                    TokenView(isPresented: self.displayTokenView,setBkgColor: bkgColor)
              //  Working with Binding
                .sheet(isPresented: self.$displayTokenView) {
                                  TokenView(isPresented: self.$displayTokenView,setBkgColor: $bkgColor)
                    
                }
            }
        }
}

struct BindingExample_Previews: PreviewProvider {
    static var previews: some View {
        BindingExample()
    }
}
// Without binding TokenView
//struct TokenView: View {

//    @State var isPresented : Bool
//    @State var setBkgColor  : Color

//    var body: some View {
//        VStack{
//            Text("Your Token")
//            Button("Dismiss Sheet") {
//                self.isPresented = false
//                self.setBkgColor = .green
//            }
//
//        }
//    }
//
//}

// With binding TokenView
struct TokenView: View {
    
    @Binding var isPresented : Bool
    @Binding var setBkgColor  : Color
    
    var body: some View {
        VStack{
            Text("Your Token N0 : 100")
            Button("Dismiss Sheet") {
                self.isPresented = false
                self.setBkgColor = .green
            }
            
        }
    }
    
}
