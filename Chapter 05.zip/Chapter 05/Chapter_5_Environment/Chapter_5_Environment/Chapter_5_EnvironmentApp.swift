//
//  Chapter_5_EnvironmentApp.swift
//  Chapter_5_Environment
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_5_EnvironmentApp: App {
    var body: some Scene {
        WindowGroup {
            Product()
        }
    }
}
