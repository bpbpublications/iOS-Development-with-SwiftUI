//
//  ContentView.swift
//  Chapter_5_Environment
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct Product: View {
    
    let productionSetting = ProductSetting()
        var body: some View {
            VStack {
                ProductionCountDisplayView()
                ProductionControlView()
            }.environmentObject(productionSetting)
        }
} 

struct Product_Previews: PreviewProvider {
    static var previews: some View {
        Product()
    }
}


struct ProductionCountDisplayView: View {
    @EnvironmentObject var productCount: ProductSetting
    var body: some View {
        Text("Product  = \(productCount.counter)")
                 .foregroundColor(.red)
}
    
}


struct ProductionControlView: View {
    @EnvironmentObject var productCurrentCount: ProductSetting
    var body: some View {
        Button(action: {
            productCurrentCount.counter = productCurrentCount.counter + 1
        }) {
            Text("Production Increased")
        }
        
    }
}
