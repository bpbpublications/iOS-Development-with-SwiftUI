//
//  ProductSetting.swift
//  Chapter_5_Environment
//
//  Created by Laxit on 01/01/22.
//

import Foundation

class ProductSetting: ObservableObject {
     @Published var counter : Int = 0
}
