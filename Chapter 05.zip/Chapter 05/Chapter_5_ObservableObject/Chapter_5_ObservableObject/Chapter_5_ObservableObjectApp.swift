//
//  Chapter_5_ObservableObjectApp.swift
//  Chapter_5_ObservableObject
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_5_ObservableObjectApp: App {
    var body: some Scene {
        WindowGroup {
            ObservedObjectModel()
        }
    }
}
