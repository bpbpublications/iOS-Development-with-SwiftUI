//
//  ContentView.swift
//  Chapter_5_ObservableObject
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct ObservedObjectModel: View {
    @ObservedObject var searchColor = SearchColorChoice()
    var body: some View {
        NavigationView{
            VStack {
                Text("Select your color")
                NavigationLink (destination:
                                    (DetailView(search:
                                                    searchColor))) {
                    Text("Selected color is " +
                         "\(searchColor.selected)")
                }
                
            }
        }
        
    }
}

struct ObservedObjectModel_Previews: PreviewProvider {
    static var previews: some View {
        ObservedObjectModel()
    }
}

struct DetailView: View {
    var colorArray = SearchColorChoice().colorArray
    var search: SearchColorChoice
    @State var selectedColor = SearchColorChoice().selected
    var body: some View {
        List {
            ForEach (colorArray, id: \.self) {
                selection in
                Button(action: {
                    self.search.selected = selection
                    self.selectedColor = selection
                }) {
                    HStack{
                        Image(systemName:
                                self.selectedColor == selection ? "checkmark.square" : "square")
                        
                        Text(selection)
                            .foregroundColor(Color.blue)
                    }
                    
                }
            }
            
        }
    }
}
                              
