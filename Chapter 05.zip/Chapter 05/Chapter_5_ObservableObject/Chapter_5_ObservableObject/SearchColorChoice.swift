//
//  SearchColorChoice.swift
//  Chapter_5_ObservableObject
//
//  Created by Laxit on 01/01/22.
//

import Foundation

class SearchColorChoice: ObservableObject {
    var colorArray = ["Red","Green","Yellow","Blue"]
    @Published var selected = "Red"
}
