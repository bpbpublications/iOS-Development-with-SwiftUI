//
//  Chapter_5_Overriding_EnvironmentKeyApp.swift
//  Chapter_5_Overriding_EnvironmentKey
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_5_Overriding_EnvironmentKeyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
