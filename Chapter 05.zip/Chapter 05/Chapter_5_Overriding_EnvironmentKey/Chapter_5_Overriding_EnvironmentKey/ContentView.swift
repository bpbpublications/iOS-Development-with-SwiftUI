//
//  ContentView.swift
//  Chapter_5_Overriding_EnvironmentKey
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        CountryDetail()
                    .environment(\.countryName, "USA")
                    .environment(\.countryCode, 01)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
