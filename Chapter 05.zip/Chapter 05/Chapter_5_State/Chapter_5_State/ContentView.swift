//
//  ContentView.swift
//  Chapter_5_State
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct ContentView: View {
    
    @State private var showingOptions = false
    @State private var accountStatus  = false
    
    var body: some View {
        VStack {
            Image(systemName: "building.2.crop.circle.fill")
                .resizable()
                .scaledToFit()
            Button {
                showingOptions = true
            }label: {
                !self.accountStatus ? Text("Active account").foregroundColor(Color.green) : Text("Account deleted ").foregroundColor(Color.red)
            }
            .confirmationDialog("Do you want to Delete this Account?", isPresented: $showingOptions, titleVisibility: .visible) {
                Button("No action") {
                    print("No action")
                }
                Button("Delete", role: .destructive) {
                    accountStatus = true
                }
            }
            
        }
          }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
