//
//  Chapter_5_StateObjectApp.swift
//  Chapter_5_StateObject
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

@main
struct Chapter_5_StateObjectApp: App {
    var body: some Scene {
        WindowGroup {
            MergeView()
        }
    }
}
