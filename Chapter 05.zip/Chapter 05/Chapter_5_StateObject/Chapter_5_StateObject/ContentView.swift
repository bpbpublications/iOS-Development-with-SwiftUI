//
//  ContentView.swift
//  Chapter_5_StateObject
//
//  Created by Laxit on 01/01/22.
//

import SwiftUI

struct MergeView: View {
    @State private var number = 0
    var body: some View {
        VStack {
            Button("Add Number") {
                number = number + 1
            }
            Text("\(number)")
                .padding()
            ContentView1()
            ContentView2()
        }
    }
}

struct MergeView_Previews: PreviewProvider {
    static var previews: some View {
        MergeView()
    }
}
struct ContentView1: View {
    @ObservedObject var dataSyn = DataSyn()
    var body: some View {
        VStack {
            Button("Increment counter") {
                dataSyn.counter += 1
            }
            Text("counter is \(dataSyn.counter)")
        }
    }
}

struct ContentView2: View {
    @StateObject var dataSyn = DataSyn()
    var body: some View {
        VStack {
            Button("Increment counter") {
                dataSyn.counter += 1
            }
            Text("counter is \(dataSyn.counter)")
        }
    }
}
