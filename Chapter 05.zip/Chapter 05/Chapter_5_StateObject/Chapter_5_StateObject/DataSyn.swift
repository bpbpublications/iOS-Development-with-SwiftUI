//
//  DataSyn.swift
//  Chapter_5_StateObject
//
//  Created by Laxit on 01/01/22.
//

import Foundation
class DataSyn: ObservableObject {
  @Published var counter = 0
}
