//
//  AlignmentguideseExApp.swift
//  AlignmentguideseEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@main
struct AlignmentguideseExApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
