//
//  ContentView.swift
//  AlignmentguideseEx
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
//        VStack(alignment: .leading) {
//                    Rectangle()
//                        .foregroundColor(Color.green)
//                        .frame(width: 120, height: 50)
//                    Rectangle()
//                        .foregroundColor(Color.yellow)
//                        .frame(width: 120, height: 50)
//                    Rectangle()
//                        .foregroundColor(Color.orange)
//                        .frame(width: 120, height: 50)
//        }
        
//        VStack(alignment: .leading) {
//                    Rectangle()
//                        .foregroundColor(Color.green)
//                        .frame(width: 120, height: 50)
//                    Rectangle()
//                        .foregroundColor(Color.yellow)
//        .alignmentGuide(HorizontalAlignment.leading, computeValue: { d in 90.0 })
//                        .frame(width: 120, height: 50)
//                    Rectangle()
//         }
//        .foregroundColor(Color.orange)
//        .alignmentGuide(HorizontalAlignment.leading,computeValue: { d in 70.0 })
//        .frame(width: 120, height: 50)
        
        
        HStack(alignment: .center) {
                    Rectangle()
                        .foregroundColor(Color.green)
                        .frame(width: 120, height: 50)
                    Rectangle()
                        .foregroundColor(Color.yellow)
        .alignmentGuide(VerticalAlignment.center,computeValue: { d in 90.0 })
                        .frame(width: 120, height: 50)
                    Rectangle()
                        .foregroundColor(Color.orange)
        .alignmentGuide(VerticalAlignment.center,computeValue: { d in 70.0 })
        .frame(width: 120, height: 50)
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
