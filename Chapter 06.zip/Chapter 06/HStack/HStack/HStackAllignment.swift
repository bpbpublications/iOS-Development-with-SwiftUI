//
//  HStackAllignment.swift
//  HStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct HStackAllignment: View {
    
    var body: some View {
        HStack(alignment: .center) {
            Text("SwiftUI")
                .foregroundColor(.white)
                .padding(10)
                .background(Color.red)
                .font(.largeTitle)
            Text("Swift")
                .foregroundColor(.white)
                .padding(5)
                .background(Color.green)
                .font(.title)
            Text("Objective C")
                .foregroundColor(.white)
                .padding(25)
                .background(Color.blue)
                .font(.footnote)
        }.border(.green)
    }
}


struct HStackAllignment_Previews: PreviewProvider {
    static var previews: some View {
        HStackAllignment()
    }
}
