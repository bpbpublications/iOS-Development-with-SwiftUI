//
//  HStackAllignmentBaseline.swift
//  HStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct HStackAllignmentBaseline: View {
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text("SwiftUI")
                .foregroundColor(.white)
                .padding(10)
                .background(Color.red)
                .font(.largeTitle)
            Text("Swift")
                .foregroundColor(.white)
                .padding(5)
                .background(Color.green)
                .font(.title)
            Text("Objective C is programming language")
                .foregroundColor(.white)
                .padding(25)
                .background(Color.blue)
                .font(.footnote)
        }.border(.green)
    }
}


struct HStackAllignmentBaseline_Previews: PreviewProvider {
    static var previews: some View {
        HStackAllignmentBaseline()
    }
}
