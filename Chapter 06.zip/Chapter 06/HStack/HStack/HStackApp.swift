//
//  HStackApp.swift
//  HStack
//
//  Created by Laxit on 02/01/22.
//

import SwiftUI

@main
struct HStackApp: App {
    var body: some Scene {
        WindowGroup {
            Priority()
        }
    }
}
