//
//  HStackSpacer.swift
//  HStack
//
//  Created by Laxit on 02/01/22.
//

import SwiftUI

struct HStackSpacer: View {
    var body: some View {
        HStack() {
           Rectangle()
            .fill(Color.orange)
            .frame(width: 100, height: 100)
            Spacer()
                .frame(minHeight: 100,  maxHeight: 200)
           Rectangle()
            .fill(Color.red)
            .frame(width: 150, height: 150)
        }
        .border(Color.green,width:2)
        }
    }


struct HStackSpacer_Previews: PreviewProvider {
    static var previews: some View {
        HStackSpacer()
    }
}
