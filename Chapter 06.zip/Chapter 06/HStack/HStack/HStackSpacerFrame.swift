//
//  HStackSpacerFrame.swift
//  HStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct HStackSpacerFrame: View {
    var body: some View {
        HStack() {
            Rectangle()
                .fill(Color.orange)
                .frame(width: 100, height: 100)
            Spacer()
                .frame(minHeight: 100,  maxHeight: 200)
            Rectangle()
                .fill(Color.red)
                .frame(width: 150, height: 150)
        }
        .border(Color.green,width:2)
    }
    }


struct HStackSpacerFrame_Previews: PreviewProvider {
    static var previews: some View {
        HStackSpacerFrame()
    }
}
