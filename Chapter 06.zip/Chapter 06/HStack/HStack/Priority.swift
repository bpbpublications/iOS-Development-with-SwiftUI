//
//  Priority.swift
//  HStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct Priority: View {
    
    var body: some View {
        HStack {
            Text("Understanding SwiftUI")
                .background(Color.orange)
            Text("Understanding SwiftUI")
                .background(Color.orange)
            Text("Understanding SwiftUI")
                .background(Color.orange)
        } }
}


struct Priority_Previews: PreviewProvider {
    static var previews: some View {
        Priority()
    }
}
