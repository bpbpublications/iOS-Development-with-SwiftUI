//
//  layoutPriority.swift
//  HStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct layoutPriority: View {
    var body: some View {
        HStack {
            Text("Understanding SwiftUI")
                .background(Color.orange)
                .layoutPriority(-1)
            Text("Understanding SwiftUI")
                .background(Color.orange)
                .layoutPriority(1)
            Text("Understanding SwiftUI")
                .background(Color.orange)
        }
        
    }
}


struct layoutPriority_Previews: PreviewProvider {
    static var previews: some View {
        layoutPriority()
    }
}
