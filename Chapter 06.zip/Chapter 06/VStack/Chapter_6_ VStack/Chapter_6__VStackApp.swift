//
//  Chapter_6__VStackApp.swift
//  Chapter_6_ VStack
//
//  Created by Laxit on 02/01/22.
//

import SwiftUI

@main
struct Chapter_6__VStackApp: App {
    var body: some Scene {
        WindowGroup {
            GeometryReader()
        }
    }
}
