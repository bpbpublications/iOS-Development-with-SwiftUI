//
//  ContentView.swift
//  Chapter_6_ VStack
//
//  Created by Laxit on 02/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            Rectangle()
                .fill(Color.orange)
                .frame(width: 150, height: 150)
        }.border(Color.green,width:2)
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
