//
//  GeometryReader.swift
//  Chapter_6_ VStack
//
//  Created by Laxit on 02/01/22.
//

import SwiftUI

struct GeometryReader: View {
    
    var body: some View {
        
        GeometryReader { geometry in
            VStack {
                Text("Welcome SwiftUI")
                    .font(.largeTitle)
                    .frame(width: geometry.size.width / 2,
                           height: (geometry.size.height / 6) * 3)
                    .border(Color.black, width: 1)
                Text("Goodbye UIKit")
                    .font(.largeTitle)
                    .frame(width: geometry.size.width / 2,
                           height: geometry.size.height / 4)
                    .border(Color.black, width: 1)
            }
        }
    }
}

struct GeometryReader_Previews: PreviewProvider {
    static var previews: some View {
        GeometryReader()
    }
}
