//
//  TextFrame.swift
//  Chapter_6_ VStack
//
//  Created by Laxit on 02/01/22.
//

import SwiftUI

struct TextFrame: View {
    var body: some View {
        Text("Understanding SwiftUI")
            .border(Color.black, width: 2)
        
        //        Text("Understanding SwiftUI")
        //            .border(Color.black, width: 2)
        //            .frame(width: 150, height: 150, alignment: .center)
        
        //        Text("Understanding SwiftUI")
        //            .font(.largeTitle)
        //            .border(Color.black, width: 2)
        //            .frame(minWidth: 100, maxWidth: 300, minHeight: 100)
//        Text("Understanding SwiftUI")
//            .font(.largeTitle)
//            .border(Color.black, width: 2)
//            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
    }
}

struct TextFrame_Previews: PreviewProvider {
    static var previews: some View {
        TextFrame()
    }
}
