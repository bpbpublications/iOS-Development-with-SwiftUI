//
//  VstackAllignment.swift
//  Chapter_6_ VStack
//
//  Created by Laxit on 02/01/22.
//

import SwiftUI

struct VstackAllignment: View {
    var body: some View {
        // allignment with center
//        VStack(alignment: .center)
//        {
//            Rectangle()
//                .fill(Color.orange)
//                .frame(width: 150, height: 150)
//            Rectangle()
//                .fill(Color.red)
//                .frame(width: 100, height: 100)
//        }
//        .border(Color.green,width:2)
        
        // allignment with leading
//        VStack(alignment: .leading)
//        {
//            Rectangle()
//                .fill(Color.orange)
//                .frame(width: 150, height: 150)
//            Rectangle()
//                .fill(Color.red)
//                .frame(width: 100, height: 100)
//        }
//        .border(Color.green,width:2)
        // allignment with leading
        VStack(alignment: .trailing)
        {
            Rectangle()
                .fill(Color.orange)
                .frame(width: 150, height: 150)
            Rectangle()
                .fill(Color.red)
                .frame(width: 100, height: 100)
        }
        .border(Color.green,width:2)
    }
}


struct VstackAllignment_Previews: PreviewProvider {
    static var previews: some View {
        VstackAllignment()
    }
}
