//
//  VstackWithTwoRectangle.swift
//  Chapter_6_ VStack
//
//  Created by Laxit on 02/01/22.
//

import SwiftUI

struct VstackWithTwoRectangle: View {
    var body: some View {
        VStack() {
            Rectangle()
                .fill(Color.orange)
                .frame(width: 150, height: 150)
            Rectangle()
                .fill(Color.gray)
                .frame(width: 100, height: 100)
        }
        .border(Color.green,width:2)
    }
}
struct VstackWithTwoRectangle_Previews: PreviewProvider {
    static var previews: some View {
        VstackWithTwoRectangle()
    }
}
