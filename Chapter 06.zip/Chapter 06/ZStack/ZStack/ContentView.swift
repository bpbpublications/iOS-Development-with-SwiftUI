//
//  ContentView.swift
//  ZStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Image("arrow")
                .padding(10)
            Text("Understanding with SwiftUI")
                .font(.largeTitle)
                .background(Color.black)
                .foregroundColor(.white)
 } }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
