//
//  LazyHGridEx.swift
//  ZStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct LazyHGridEx: View {
    var gridItems: [GridItem] = [GridItem(),GridItem(),GridItem()]
        var body: some View {
            NavigationView() {
    ScrollView(.horizontal) {
    LazyHGrid(rows: gridItems,alignment: .top,spacing: 20){
    ForEach((1...1000), id: \.self) {
        Text("\($0)")
            .font(.footnote)
            .frame(minWidth: 0, maxWidth:.infinity ,
            minHeight: 50)
            .background(Color.orange)
    }}}.navigationTitle("Lazy Grids")
}
        }
}

struct LazyHGridEx_Previews: PreviewProvider {
    static var previews: some View {
        LazyHGridEx()
    }
}
