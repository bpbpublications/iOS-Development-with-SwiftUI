//
//  LazyHStackEx.swift
//  ZStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct LazyHStackEx: View {
    var body: some View {
     ScrollView {
       LazyVStack(alignment: .leading) {
           ForEach(1...100, id: \.self) {
               Text("Row \($0)")
    } }
    }
    }
    }

struct LazyHStackEx_Previews: PreviewProvider {
    static var previews: some View {
        LazyHStackEx()
    }
}
