//
//  LazyVGrid.swift
//  ZStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct LazyVGrid1: View {
    var gridItems: [GridItem] = [GridItem(),GridItem(),GridItem()]
    var body: some View {
        NavigationView() {
            ScrollView() {
                LazyVGrid(columns: gridItems,alignment:
                                .center,spacing: 20){
                    ForEach((1...1000), id: \.self) {
                        Text("\($0)")
                            .font(.footnote)
                            .frame(minWidth: 0, maxWidth:.infinity , minHeight: 50)
                            .background(Color.orange)
                    }
                    
                }
            }.navigationTitle("Lazy Grids")
                
        }
        
    }
    
}


struct LazyVGrid1_Previews: PreviewProvider {
    static var previews: some View {
        LazyVGrid1()
    }
}
