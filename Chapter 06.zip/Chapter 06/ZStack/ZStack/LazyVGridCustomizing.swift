//
//  LazyVGridCustomizing.swift
//  ZStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct LazyVGridCustomizing: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LazyVGridCustomizing_Previews: PreviewProvider {
    static var previews: some View {
        LazyVGridCustomizing()
    }
}
