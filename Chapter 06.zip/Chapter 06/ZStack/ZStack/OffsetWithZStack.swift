//
//  OffsetWithZStack.swift
//  ZStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct OffsetWithZStack: View {
   
        var body: some View {
            ZStack {
                Image("arrow")
                    .padding(10)
                Text("Understanding with SwiftUI")
      .font(.largeTitle)
      .background(Color.black)
      .foregroundColor(.white)
      .offset(x:0, y: -200)
}
        }
    
}

struct OffsetWithZStack_Previews: PreviewProvider {
    static var previews: some View {
        OffsetWithZStack()
    }
}
