//
//  ZStackApp.swift
//  ZStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

@main
struct ZStackApp: App {
    var body: some Scene {
        WindowGroup {
            zIndex()
        }
    }
}
