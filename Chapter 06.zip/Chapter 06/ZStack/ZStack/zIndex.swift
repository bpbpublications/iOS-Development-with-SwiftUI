//
//  zIndex.swift
//  ZStack
//
//  Created by Laxit on 04/01/22.
//

import SwiftUI

struct zIndex: View {
    var body: some View {
        ZStack(alignment: .leading) {
            Rectangle()
                .fill(Color.orange)
                .frame(width: 100, height: 100)
                .zIndex(1)
            Rectangle()
                .fill(Color.red)
                .frame(width: 150, height: 150)
        }
    }
    
}

struct zIndex_Previews: PreviewProvider {
    static var previews: some View {
        zIndex()
    }
}
