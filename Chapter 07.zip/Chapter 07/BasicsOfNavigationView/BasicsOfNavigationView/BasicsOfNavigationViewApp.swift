//
//  BasicsOfNavigationViewApp.swift
//  BasicsOfNavigationView
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

@main
struct BasicsOfNavigationViewApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationBarItems()
        }
    }
}
