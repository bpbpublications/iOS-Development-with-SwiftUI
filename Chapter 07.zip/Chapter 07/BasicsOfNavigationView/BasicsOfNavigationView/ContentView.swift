//
//  ContentView.swift
//  BasicsOfNavigationView
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack{
              Text("Navigation View")
            }
            //.navigationBarTitle("Navigation", displayMode: .large)
             //.navigationBarTitle("Navigation", displayMode: .inline)
} }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

