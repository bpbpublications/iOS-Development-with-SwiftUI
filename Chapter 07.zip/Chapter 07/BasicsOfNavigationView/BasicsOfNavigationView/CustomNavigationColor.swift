//
//  CustomNavigationColor.swift
//  BasicsOfNavigationView
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct CustomNavigationColor: View {
    var body: some View {
        NavigationView{
            VStack{
              Text("Navigation View")
            }.navigationBarTitle("Beautiful Places", displayMode: .large).navigationBarColor(backgroundColor: .yellow, tintColor: .red)
        
    }
}
}

struct CustomNavigationColor_Previews: PreviewProvider {
    static var previews: some View {
        CustomNavigationColor()
    }
}

struct NavigationBarColor: ViewModifier {
    var backgroundColor: UIColor?
    var tintColor :UIColor?
    init(backgroundColor: UIColor, tintColor: UIColor) {
        self.backgroundColor = backgroundColor
        let coloredAppearance = UINavigationBarAppearance()
        coloredAppearance.configureWithTransparentBackground()
        coloredAppearance.backgroundColor = .clear
        coloredAppearance.titleTextAttributes = [.foregroundColor: tintColor]
        coloredAppearance.largeTitleTextAttributes=[.foregroundColor: tintColor]
        UINavigationBar.appearance().standardAppearance =
        coloredAppearance
        UINavigationBar.appearance().compactAppearance =
        coloredAppearance
        UINavigationBar.appearance().scrollEdgeAppearance =
        coloredAppearance
        UINavigationBar.appearance().tintColor = tintColor
    }
    func body(content: Content) -> some View {
        ZStack{
            content
            VStack {
                GeometryReader { geometry in
                    Color(self.backgroundColor ?? .clear)
                        .frame(height: geometry.safeAreaInsets.top)
                        .edgesIgnoringSafeArea(.top)
                    Spacer()
                } }
        } }
}
extension View {
    func navigationBarColor(backgroundColor: UIColor, tintColor: UIColor) -> some View {
        self.modifier(NavigationBarColor(backgroundColor:backgroundColor, tintColor: tintColor))
    }
    
}
