//
//  ListInsideTheNavigationView.swift
//  BasicsOfNavigationView
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI
struct BeautifulPlaces: Identifiable {
  var id = UUID()
  var name: String
}
let BeautifulPlacesList: [BeautifulPlaces] = [
        BeautifulPlaces(name: "ANGEL FALLS"),
        BeautifulPlaces(name: "ANTARCTICA"),
        BeautifulPlaces(name: "BANFF NATIONAL PARK"),
        BeautifulPlaces(name: "TAJ MAHAL"),
        BeautifulPlaces(name: "CAPPADOCIA")]
struct ListInsideTheNavigationView: View {
    var body: some View {
        NavigationView{
            List {
                ForEach(BeautifulPlacesList)   { BeautifulPlaces in
                    Text(BeautifulPlaces.name)
                }
            }.navigationBarTitle("Beautiful Places", displayMode: .inline)
                .navigationBarItems(trailing:
                                        Button(action: {
                    print("Remove button pressed...")
                }) {
                    Image(systemName: "trash.fill").imageScale(.large)
                   // Text("Remove")
                })
            
        }
    }
}

struct ListInsideTheNavigationView_Previews: PreviewProvider {
    static var previews: some View {
        ListInsideTheNavigationView()
    }
}
