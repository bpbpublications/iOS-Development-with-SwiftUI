//
//  NavigationBarItems.swift
//  BasicsOfNavigationView
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct NavigationBarItems: View {
    var body: some View {
        NavigationView{
            List {
                ForEach(BeautifulPlacesList)   { BeautifulPlaces in
                    Text(BeautifulPlaces.name)
                }
            }.navigationBarTitle("Beautiful Places", displayMode: .inline)
                .navigationBarItems(trailing:
                                        HStack {
                    Button(action: {
                        print("Removed button pressed...")
                    }) {
                        Image(systemName: "trash.fill").imageScale(.large)
                    }
                    Spacer()
                    Button(action: {
                        print("Already Removed button pressed...")
                    }) {
                        Image(systemName: "trash").imageScale(.large)
                    }
                } )
            
        }
    }
}

struct NavigationBarItems_Previews: PreviewProvider {
    static var previews: some View {
        NavigationBarItems()
    }
}
