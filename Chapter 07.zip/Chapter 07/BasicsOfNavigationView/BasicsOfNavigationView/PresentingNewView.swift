//
//  PresentingNewView.swift
//  BasicsOfNavigationView
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct PresentingNewView: View {
    
    var body: some View {
        NavigationView{
            NavigationLink(destination: Text("Push View")) {
                Text("Navigation Link")
                //Image("arrow")
            }.navigationBarTitle("Navigation")
        }
    }
}


struct PresentingNewView_Previews: PreviewProvider {
    static var previews: some View {
        PresentingNewView()
    }
}
