//
//  ContentView.swift
//  ListEx
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        List{
            Text("ANGEL FALLS")
                .foregroundColor(.red)
                .bold()
            Text("ANTARCTICA")
                .foregroundColor(.green)
                .underline()
            Text("BANFF NATIONAL PARK")
                .foregroundColor(.blue)
                .kerning(-2)
            Text("TAJ MAHAL")
                .foregroundColor(.orange)
                .tracking(6)
            Text("CAPPADOCIA")
                .foregroundColor(.yellow)
                .strikethrough(true, color: .red)
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
