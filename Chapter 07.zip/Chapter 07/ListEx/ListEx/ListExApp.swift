//
//  ListExApp.swift
//  ListEx
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

@main
struct ListExApp: App {
    var body: some Scene {
        WindowGroup {
            SwipeActionsInListRows()
        }
    }
}
