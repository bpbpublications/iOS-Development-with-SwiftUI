//
//  SeparatorsModifier.swift
//  ListEx
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct SeparatorsModifier: View {
   
    var body: some View {
        List {
        ForEach(BeautifulPlacesList)   { BeautifulPlaces in
            Text(BeautifulPlaces.name)
                     //.listRowSeparator(.hidden)
                     .listRowSeparatorTint(.red)
        }
        }
    }
}

struct SeparatorsModifier_Previews: PreviewProvider {
    static var previews: some View {
        SeparatorsModifier()
    }
}
