//
//  SwipeActionsInListRows.swift
//  ListEx
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct SwipeActionsInListRows: View {
    
    var body: some View {
        List {
            ForEach(BeautifulPlacesList)   { BeautifulPlaces in
                Text(BeautifulPlaces.name)
                
            }.swipeActions(){
                Button
                {
                    print("Pin")
                }label: {
                    Label("pin",systemImage: "pin")
                }
                .tint(.green)
                Button(role:.cancel)
                {
                    print("Delete")
                } label: {
                    Label("Delete", systemImage: "trash")
                }
                .tint(.red)
            }
        }
    }
}
   


struct SwipeActionsInListRows_Previews: PreviewProvider {
    static var previews: some View {
        SwipeActionsInListRows()
    }
}
