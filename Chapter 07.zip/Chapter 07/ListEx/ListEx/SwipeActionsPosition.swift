//
//  SwipeActionsPosition.swift
//  ListEx
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct SwipeActionsPosition: View {
   
    var body: some View {
        List {
            ForEach(BeautifulPlacesList)   { BeautifulPlaces in
                Text(BeautifulPlaces.name)
                
            }.swipeActions(edge: .trailing){
                Button
                {
                    print("Pin")
                }label: {
                    Label("pin",systemImage: "pin")
                }
                .tint(.green)
            }
            .swipeActions(edge: .leading){
                Button(role:.cancel)
                {
                    print("Delete")
                } label: {
                    Label("Delete", systemImage: "trash")
                }
                .tint(.red)
            }
        }
    }
}

struct SwipeActionsPosition_Previews: PreviewProvider {
    static var previews: some View {
        SwipeActionsPosition()
    }
}
