//
//  SectionInList.swift
//  ListEx
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI
struct Food: Identifiable {
    var id = UUID()
    var name:String
    var foodtype:FoodType
}
enum FoodType: String, CaseIterable {
    case Indian = "Indian Dish"
    case Chinese = "Chinese Dish"
    case Italian = "Italian Dish"
    case Mexican = "Mexican Dish"
}
var foodItems = [
    Food(name: "Chicken Tikka Masala", foodtype: .Indian),
    Food(name: "Fried Rice", foodtype: .Chinese),
    Food(name: "Pozole", foodtype: .Mexican),
    Food(name: "Samosa", foodtype: .Indian),
    Food(name: "Pasta varieties", foodtype: .Italian),
    Food(name: "Tikka Masala", foodtype: .Indian),
    Food(name: "Crab Rangoon", foodtype: .Chinese),
    Food(name: "Tostadas", foodtype: .Mexican),
    Food(name: "Vindaloo", foodtype: .Indian),
    Food(name: "Pasta dishes", foodtype: .Italian)
]

struct SectionInList: View {
    var body: some View {
        List {
            ForEach(FoodType.allCases, id: \.rawValue) { foodtype in
                Section(header: Text(foodtype.rawValue)) {
                    ForEach(foodItems.filter { $0.foodtype == foodtype }) { movie in
                        VStack(alignment: .leading) {
                            Text(movie.name).fontWeight(.semibold)
                                .listRowSeparatorTint(.green)
                               .badge(movie.foodtype.rawValue)
                        }
                    }
                }
            }
        }
    }
}

struct SectionInList_Previews: PreviewProvider {
    static var previews: some View {
        SectionInList()
    }
}
