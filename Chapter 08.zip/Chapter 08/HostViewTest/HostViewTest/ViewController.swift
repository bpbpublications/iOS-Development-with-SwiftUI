//
//  ViewController.swift
//  HostViewTest
//
//  Created by Laxit on 04/03/21.
//

import UIKit
import SwiftUI

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBSegueAction func ShowSwiftUIView(_ coder: NSCoder) -> UIViewController? {
        return UIHostingController(coder: coder,
                                   rootView: SwiftUIView())
    }
    
}

