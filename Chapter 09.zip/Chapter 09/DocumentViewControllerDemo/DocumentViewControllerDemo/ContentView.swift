//
//  ContentView.swift
//  DocumentViewControllerDemo
//
//  Created by Laxit on 08/03/21.
//

import SwiftUI

struct ContentView: View {
    //display the document picker
    @State var isDocumentPickerPresented: Bool = false
    @State var documentUrl: String = ""
   
    var body: some View {
        VStack(alignment: .center){
            Image("icon")
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 100, alignment: .top)
            DocumentName(content: self.$documentUrl)
                .frame(height: 35)
            Button("Select document") {
                self.isDocumentPickerPresented.toggle()
            }
            .frame(height: 40, alignment: .center)
            .sheet(isPresented: self.$isDocumentPickerPresented, content: {
                DocumentPickerViewController(documentURL: self.$documentUrl)

            })
        }
        .padding(15)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
