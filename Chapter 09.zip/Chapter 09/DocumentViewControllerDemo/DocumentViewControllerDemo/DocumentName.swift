//
//  DocumentName.swift
//  DocumentViewControllerDemo
//
//  Created by Laxit on 04/01/22.
//

import Foundation
import SwiftUI

struct DocumentName: UIViewRepresentable {
    @Binding var content: String
    func makeUIView(context: Context) -> UILabel {
        let label = UILabel()
        label.backgroundColor = .darkGray
        label.textColor = .white
        return label
    }
    func updateUIView(_ uiView: UILabel, context: Context) {
        uiView.text = content
    }
}
