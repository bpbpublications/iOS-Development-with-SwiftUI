//
//  DocumentPickerViewController.swift
//  DocumentViewControllerDemo
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI
import MobileCoreServices
import UniformTypeIdentifiers

struct DocumentPickerViewController: UIViewControllerRepresentable
{   @Binding var documentURL : String
    func makeCoordinator() -> Coordinator {
        return Coordinator(documentController: self)
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController,
                                context: UIViewControllerRepresentableContext<DocumentPickerViewController>) {
    }
    func makeUIViewController(context: Context) ->
    UIDocumentPickerViewController {
        let supportedTypes: [UTType] = [UTType.pdf]
      
        let controller = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes, asCopy: true)
       
        controller.delegate = context.coordinator
        
        return controller
    }
   
class Coordinator: NSObject, UIDocumentPickerDelegate {
    var documentController: DocumentPickerViewController
    
    init(documentController: DocumentPickerViewController) {
        self.documentController = documentController
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first, url.startAccessingSecurityScopedResource() else { return }
        defer { url.stopAccessingSecurityScopedResource() }
        documentController.documentURL = String(urls[0].lastPathComponent)
    }
}
}
