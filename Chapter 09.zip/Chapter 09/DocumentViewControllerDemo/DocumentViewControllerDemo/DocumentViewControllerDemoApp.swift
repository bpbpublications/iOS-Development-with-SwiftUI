//
//  DocumentViewControllerDemoApp.swift
//  DocumentViewControllerDemo
//
//  Created by Laxit on 08/03/21.
//

import SwiftUI

@main
struct DocumentViewControllerDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
