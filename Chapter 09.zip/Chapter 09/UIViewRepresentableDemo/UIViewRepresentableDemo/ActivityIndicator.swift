//
//  ActivityIndicator.swift
//  UIViewRepresentableDemo
//
//  Created by Laxit on 05/03/21.
//

import SwiftUI

struct ActivityIndicator: View {
    @State var buttonCaption = " Start Animation"
    @State var animating = false

        var body: some View {
            VStack{
                Button(action: {
                    self.animating.toggle()
                    self.buttonCaption = self.animating ?
                                       "Stop Animation" : "Start Animation"
                }){
                    Text(self.buttonCaption).padding()
                }
                UIKitActivityIndicator(isAnimating: $animating)
            }
        }
}

struct ActivityIndicator_Previews: PreviewProvider {
    static var previews: some View {
        ActivityIndicator()
    }
}

struct UIKitActivityIndicator: UIViewRepresentable {

    @Binding var isAnimating: Bool

    func makeUIView(context: Context) -> UIActivityIndicatorView {
        let view = UIActivityIndicatorView()
        return view
    }

    func updateUIView(_ activityIndicator: UIActivityIndicatorView, context: Context) {
        isAnimating ? activityIndicator.startAnimating() : activityIndicator.stopAnimating()
    }
}


