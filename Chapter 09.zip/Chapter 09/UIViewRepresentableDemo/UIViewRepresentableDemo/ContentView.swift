//
//  ContentView.swift
//  UIViewRepresentableDemo
//
//  Created by Laxit on 05/03/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            UIKitUILabel(message: "Welcome UIKit")
               
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct UIKitUILabel: UIViewRepresentable {
    
    var message: String
    
    func makeUIView(context: UIViewRepresentableContext<UIKitUILabel>)
    -> UILabel {
        let myLabel = UILabel()
        myLabel.text = message
        return myLabel
    }
    
    func updateUIView(_ uiView: UILabel,
                      context: UIViewRepresentableContext<UIKitUILabel>) {
    }
}

struct MyUILabel_Previews: PreviewProvider {
    static var previews: some View {
        UIKitUILabel(message: "Hey")
}
    }
//------
//
//  ActivityIndicator.swift
//  UIViewRepresentableDemo
//
//  Created by Laxit on 05/03/21.
//

//import SwiftUI
//
//struct ActivityIndicator: View {
//    @State var buttonCaption = "Start"
//        @State var animating = false
//     
//        var body: some View {
//            VStack{
//                Button(action: {
//                    self.animating.toggle()
//                    self.buttonCaption = self.animating ?
//                                       "Stop" : "Start"
//                }){
//                    Text(self.buttonCaption).padding()
//                }
//                UIKitActivityIndicator(isAnimating: $animating)
//            }
//        }
//}
//
//struct ActivityIndicator_Previews: PreviewProvider {
//    static var previews: some View {
//        ActivityIndicator()
//    }
//}
//
//struct UIKitActivityIndicator: UIViewRepresentable {
// 
//    @Binding var isAnimating: Bool
// 
//    func makeUIView(context: Context) -> UIActivityIndicatorView {
//        let view = UIActivityIndicatorView()
//        return view
//    }
// 
//    func updateUIView(_ activityIndicator: UIActivityIndicatorView, context: Context) {
//        isAnimating ? activityIndicator.startAnimating() : activityIndicator.stopAnimating()
//    }
//}


