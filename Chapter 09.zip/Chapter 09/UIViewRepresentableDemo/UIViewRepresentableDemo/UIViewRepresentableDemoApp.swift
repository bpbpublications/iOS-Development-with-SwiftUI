//
//  UIViewRepresentableDemoApp.swift
//  UIViewRepresentableDemo
//
//  Created by Laxit on 05/03/21.
//

import SwiftUI

@main
struct UIViewRepresentableDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
