//
//  ContentView.swift
//  3Drotation
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI

struct ContentView: View {
    @State private var isSpinning: Bool = true
    var body: some View {
        VStack{
            Button(action: {
                withAnimation {
                    self.isSpinning.toggle()
                } }) {
                    Image("wheel")
                        .renderingMode(.original)
                }
                .frame(width: 100, height: 100, alignment: .center)
                .clipShape(Circle())
                .rotation3DEffect(.degrees(isSpinning ? 0 : 360), axis:
                                    (x: 1, y:0, z: 0))
                .animation(Animation.linear(duration: 5)
                            .repeatForever(autoreverses: false),value: 0)
        }
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
