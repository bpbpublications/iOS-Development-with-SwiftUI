//
//  AsymmetricTransitionsApp.swift
//  AsymmetricTransitions
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

@main
struct AsymmetricTransitionsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
