//
//  ContentView.swift
//  AsymmetricTransitions
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct ContentView: View {
    @State private var transition: Bool = true
    var body: some View {
        Button("SwiftUI Basic Transitions") {
                       withAnimation {
                           self.transition.toggle()
                       }
                }.background(Color.green)
                   if transition {
                       Text("(click me again)")
                           .transition(.asymmetric(insertion: .opacity,
                           removal: .slide))
        }

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
