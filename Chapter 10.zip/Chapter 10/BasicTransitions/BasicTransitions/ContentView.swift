//
//  ContentView.swift
//  BasicTransitions
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct ScaleAnimation: View {
    @State private var transition: Bool = true
    var body: some View {
        Button("Basic Transitions") {
            withAnimation {
                self.transition.toggle()
            }}
        if transition {
            Text("Understanding SwiftUI")
                .transition(.scale)
        }
        
    }
}
    

struct ScaleAnimation_Previews: PreviewProvider {
    static var previews: some View {
        ScaleAnimation()
    }
}
