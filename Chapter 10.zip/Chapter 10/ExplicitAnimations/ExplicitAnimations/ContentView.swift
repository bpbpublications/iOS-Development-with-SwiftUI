//
//  ContentView.swift
//  ExplicitAnimations
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI

struct ContentView: View {
    @State var opacity = 0.0
    var body: some View {
        VStack {
            Button("Tap to Animate") {
                withAnimation(Animation.easeOut(duration: 10)) {
                    self.opacity = (self.opacity == 1.0) ? 0 : 1.0
                } }
            Text("Understanding SwiftUI")
                .opacity(opacity)
                
        } }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
