//
//  ExplicitAnimationsApp.swift
//  ExplicitAnimations
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI

@main
struct ExplicitAnimationsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
