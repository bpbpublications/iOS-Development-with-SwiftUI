//
//  ContentView.swift
//  ImplicitAnimation
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI

struct ContentView: View {
    @State var opacity = 0.0
    var body: some View {
        VStack {
            Button("Tap to Animate") {
                self.opacity = (self.opacity == 1.0) ? 0 : 1.0
            }
            Text("Understanding SwiftUI")
            .opacity(opacity)
            .animation(.default,value: true)
        }
} }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
