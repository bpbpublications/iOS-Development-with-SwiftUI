//
//  ImplicitAnimationApp.swift
//  ImplicitAnimation
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI

@main
struct ImplicitAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
