//
//  InitialVelocityAniApp.swift
//  InitialVelocityAni
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

@main
struct InitialVelocityAniApp: App {
    var body: some Scene {
        WindowGroup {
            InitialVelocityAni()
        }
    }
}
