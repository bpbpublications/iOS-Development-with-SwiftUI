//
//  ContentView.swift
//  InterpolatingSpringAnimation
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct InterPolating: View {
    @State private var angle: Double = 0
    var body: some View {
        Button("Understanding SwiftUI") {
            angle += 30
}
        .background(Color.green)
        .padding()
        .rotationEffect(.degrees(angle))
        .animation(.interpolatingSpring(stiffness:200,  damping:0.5),value: angle)
         
} }

struct InterPolating_Previews: PreviewProvider {
    static var previews: some View {
        InterPolating()
    }
}
