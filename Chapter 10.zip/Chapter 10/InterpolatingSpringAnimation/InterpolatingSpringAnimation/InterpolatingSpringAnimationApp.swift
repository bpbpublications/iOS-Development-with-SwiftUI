//
//  InterpolatingSpringAnimationApp.swift
//  InterpolatingSpringAnimation
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

@main
struct InterpolatingSpringAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            InterPolating()
        }
    }
}
