//
//  ContentView.swift
//  Mass
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct Interpolating: View {
    @State private var angle: Double = 0
    var body: some View {
        Button("Understanding SwiftUI") {
            angle += 30
        }
        .background(Color.green)
        .padding()
        .rotationEffect(.degrees(angle))
.animation(.interpolatingSpring(mass: 1, stiffness: 200, damping: 0.5),value: angle)
}
    
}
struct Interpolating_Previews: PreviewProvider {
    static var previews: some View {
        Interpolating()
    }
}
