//
//  MassApp.swift
//  Mass
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

@main
struct MassApp: App {
    var body: some Scene {
        WindowGroup {
            Interpolating()
        }
    }
}
