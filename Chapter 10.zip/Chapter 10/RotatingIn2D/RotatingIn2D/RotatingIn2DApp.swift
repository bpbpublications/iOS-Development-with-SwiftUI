//
//  RotatingIn2DApp.swift
//  RotatingIn2D
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI

@main
struct RotatingIn2DApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
