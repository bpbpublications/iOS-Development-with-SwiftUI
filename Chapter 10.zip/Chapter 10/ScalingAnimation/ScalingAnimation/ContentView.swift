//
//  ContentView.swift
//  ScalingAnimation
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI

struct ContentView: View {
    @State private var scaleFactor: CGFloat = 0.5
    var body: some View {
        Button(action: {
            self.scaleFactor = 2.5
        }) {
            Text("SwiftUI")
                .bold()
                .lineLimit(2)
        }
        .padding(50)
        .background(Color.blue)
        .foregroundColor(.white)
        .clipShape(Capsule())
        .scaleEffect(scaleFactor)
    } }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
