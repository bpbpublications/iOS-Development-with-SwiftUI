//
//  ScalingAnimationApp.swift
//  ScalingAnimation
//
//  Created by Laxit on 08/01/22.
//

import SwiftUI

@main
struct ScalingAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
