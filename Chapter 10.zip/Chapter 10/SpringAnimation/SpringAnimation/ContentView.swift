//
//  ContentView.swift
//  SpringAnimation
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct ContentView: View {
    @State private var show = false
    @State private var phase = 0

    var body: some View {
        VStack{
            RoundedRectangle(cornerRadius: 40)
                .fill(Color(.cyan))
                .overlay(Image("dollar"))
                .padding()
                .scaleEffect(show ? 1 : 0.01, anchor: .bottom)
                .opacity(show ? 1 : 0)
                .animation(.spring(),value: phase)
                //.animation(.spring())
            Button(action: {
                advanceAnimationPhase()
                self.show.toggle()
            }, label: {
                Image(systemName: show ? "square.and.arrow.up.on.square.fill" : "square.and.arrow.down")
                    .foregroundColor(.green)
                    .font(.largeTitle)
            })
        }
    }
    func advanceAnimationPhase() {
        if show {
            phase = Int(1.0)
        }else{
            phase = Int(0.01)
        }
    }
    
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
