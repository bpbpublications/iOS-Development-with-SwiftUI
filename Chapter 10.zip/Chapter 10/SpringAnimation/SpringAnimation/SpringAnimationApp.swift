//
//  SpringAnimationApp.swift
//  SpringAnimation
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

@main
struct SpringAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
