//
//  ContentView.swift
//  SpringBlendDuration
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct ContentView: View {
    @State private var change = false
    @State private var response = 2.0
    @State private var blendDuration = 1.0
    @State private var phase = 0.0
    var body: some View {
        VStack(spacing: 5) {
            Circle()
                .scaleEffect(change ? 0.2 : 1)
                .foregroundColor(Color(.green))
                .animation(.spring(response:response,dampingFraction:
                                0.5, blendDuration: blendDuration),value: phase)
                            Text("Response").padding(.top)
                            HStack {
                                Image(systemName: "1.circle.fill")
                                Slider(value: $response, in: 1...2)
                                Image(systemName: "2.circle.fill")
                            }
                            Text("Blend Duration")
                            HStack {
                                Image(systemName: "0.circle.fill")
                                Slider(value: $blendDuration, in: 0...2)
                                Image(systemName: "2.circle.fill")
                                }
                                Button("Change") {
                                    advanceAnimationPhase()
                                    self.change.toggle()
                                }.foregroundColor(Color(.cyan))
                            .font(.title)
                            .foregroundColor(Color(.blue))
                            .padding(.horizontal)
                } }
    func advanceAnimationPhase() {
            if  self.change {
                phase = 1.0
            }else{
                phase = 0.2
            }
        }
                }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
