//
//  ContentView.swift
//  TransitionMove
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct BounceAnimations: View {
    @State private var transition: Bool = true
    var body: some View {
        Button("Basic Transitions") {
              withAnimation(.interpolatingSpring(stiffness:  30.0,  damping:
              1.0)) {
                    self.transition.toggle()
                }
                }
                .padding(.top, 15)
                if transition {
                    Text("Learn SwiftUI")
                        .transition(.move(edge: .bottom))
        } }
        }

struct BounceAnimations_Previews: PreviewProvider {
    static var previews: some View {
        BounceAnimations()
    }
}
