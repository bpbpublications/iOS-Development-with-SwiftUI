//
//  CapsuleDrawingApp.swift
//  CapsuleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

@main
struct CapsuleDrawingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
