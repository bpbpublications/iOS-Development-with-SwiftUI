//
//  FillColor.swift
//  CapsuleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct FillColor: View {
    var body: some View {
        Capsule()
                  .fill(Color.blue)
                   .frame(width: 150, height: 150)
            }
    }


struct FillColor_Previews: PreviewProvider {
    static var previews: some View {
        FillColor()
    }
}
