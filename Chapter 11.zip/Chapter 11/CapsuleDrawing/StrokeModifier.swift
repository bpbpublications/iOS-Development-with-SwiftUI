//
//  StrokeModifier.swift
//  CapsuleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct StrokeModifier: View {
    var body: some View {
        Capsule()
                    .stroke(lineWidth: 10)
                   .foregroundColor(Color.orange)
                   .frame(width: 150, height: 50)
            }
    }


struct StrokeModifier_Previews: PreviewProvider {
    static var previews: some View {
        StrokeModifier()
    }
}
