//
//  CircleDrawingApp.swift
//  CircleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

@main
struct CircleDrawingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
