//
//  ContentView.swift
//  CircleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
              Circle()
                    .frame(width: 150, height: 150)
} }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
