//
//  FillRadialGradient.swift
//  CircleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct FillRadialGradient: View {
    var body: some View {
        Circle()
          .fill(RadialGradient(
        gradient: Gradient(colors: [.green, .yellow]), center: .center,
                      startRadius: 0,
                      endRadius: 75))
              .frame(width: 150, height: 150)
    }
}

struct FillRadialGradient_Previews: PreviewProvider {
    static var previews: some View {
        FillRadialGradient()
    }
}
