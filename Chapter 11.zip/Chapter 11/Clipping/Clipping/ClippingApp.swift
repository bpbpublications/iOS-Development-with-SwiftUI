//
//  ClippingApp.swift
//  Clipping
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

@main
struct ClippingApp: App {
    var body: some Scene {
        WindowGroup {
            TajMahalShadow()
        }
    }
}
