//
//  ContentView.swift
//  Clipping
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI
 //------ with Circle / Rectangle
//struct ContentView: View {
//    var body: some View {
//        Image("TajMahal")
//           .resizable()
//           .aspectRatio(contentMode: .fill)
//           .frame(width: 320.0, height: 440.0)
//          // .clipShape(Circle())
//           .clipShape(Rectangle())
//} }


struct ContentView: View {
    var body: some View  {
        Image("TajMahal")
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(width: 320.0, height: 440.0)
            .clipShape(RoundedRectangle(cornerRadius: 20, style:
                                                .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.black,lineWidth:10)
                    .shadow(radius: 10)
            )
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
