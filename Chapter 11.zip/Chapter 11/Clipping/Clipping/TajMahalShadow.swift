//
//  TajMahalShadow.swift
//  Clipping
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct TajMahalShadow: View {
    var body: some View {
    Image("TajMahal")
        .resizable()
        .aspectRatio(contentMode: .fill)
        .frame(width: 320.0, height: 440.0)
        .clipShape(Circle())
                 .overlay(
                      Circle()
                            .stroke(Color.blue, lineWidth: 20)
                            .offset(x: 10.0, y: 10.0)
                            .clipped()
        ) .overlay(
                        Circle()
                            .stroke(Color.green, lineWidth: 20)
                            .offset(x: -0.0, y: -8.0)
                            .clipped()
        )
    }
}

struct TajMahalShadow_Previews: PreviewProvider {
    static var previews: some View {
        TajMahalShadow()
    }
}
