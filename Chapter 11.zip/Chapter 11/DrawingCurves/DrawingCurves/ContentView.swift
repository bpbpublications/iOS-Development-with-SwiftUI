//
//  ContentView.swift
//  DrawingCurves
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
        MyShape()
            .fill(Color.purple)
        MyShape1()
            .fill(Color.red)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
struct MyShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addArc(
            center: CGPoint(x: rect.size.width/2, y: rect.size.height/4),
                    radius: rect.width/4,
                    startAngle: .degrees(20),
                    endAngle: .degrees(180),
                    clockwise: false)
        path.addLine(to: CGPoint(x: rect.size.width/2, y: rect.size.height/4))
        return path
    }
}
struct MyShape1: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addArc(
            center: CGPoint(x: rect.size.width/2, y: rect.size.height/4),
                    radius: rect.width/4,
                    startAngle: .degrees(20),
                    endAngle: .degrees(180),
                    clockwise: true)
        path.addLine(to: CGPoint(x: rect.size.width/2, y: rect.size.height/4))
        return path
    }
}
