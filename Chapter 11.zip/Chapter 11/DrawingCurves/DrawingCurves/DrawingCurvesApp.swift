//
//  DrawingCurvesApp.swift
//  DrawingCurves
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

@main
struct DrawingCurvesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
