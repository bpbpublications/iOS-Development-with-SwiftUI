//
//  DrawingCustomPathAndShapes_swiftApp.swift
//  DrawingCustomPathAndShapes.swift
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

@main
struct DrawingCustomPathAndShapes_swiftApp: App {
    var body: some Scene {
        WindowGroup {
            ShapeProtocol()
        }
    }
}
