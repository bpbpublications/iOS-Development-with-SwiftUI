//
//  ShapeProtocol .swift
//  DrawingCustomPathAndShapes.swift
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

//public protocol Shape : Animatable, View {
// {
//    func path(in rect: CGRect) -> Path
//}
struct ShapeProtocol: View {
    var body: some View {
        MyTriangle()
            .stroke(Color.red,lineWidth: 3)
} }


struct  MyTriangle: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 20, y: 20))
        path.addLine(to: CGPoint(x: 20, y: 400))
        path.addLine(to: CGPoint(x: 300, y: 200))
        //path.closeSubpath()
        return path
        
    }
}
    
    
