//
//  EllipseOverlays.swift
//  EllipseDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct EllipseOverlays: View {
    var body: some View {
        Ellipse()
                   .fill(Color.red)
                   .frame(width: 150, height: 50)
                   .overlay(Ellipse()
                   .stroke(Color.blue, lineWidth: 10))
        }
    }


struct EllipseOverlays_Previews: PreviewProvider {
    static var previews: some View {
        EllipseOverlays()
    }
}
