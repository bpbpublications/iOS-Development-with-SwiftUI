//
//  ScalingDrawing.swift
//  EllipseDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct ScalingDrawing: View {
    var body: some View {
        Ellipse()
            .stroke(lineWidth: 10)
            .foregroundColor(Color.orange)
            .frame(width: 150, height: 50)
            .scaleEffect(0.5)
        
        
        Image(systemName: "envelope.badge.fill")
            .resizable()
            .frame(width: 150, height: 150, alignment: .center) .foregroundColor(Color.green)
            .scaleEffect(x: 1, y: 3)
        
        Image(systemName: "envelope.badge.fill")
            .resizable()
            .frame(width: 150, height: 150, alignment: .center) .foregroundColor(Color.green)
            .scaleEffect(x: 0.5, y: 0.5, anchor: .bottomTrailing) .border(Color.red)
        
        Image(systemName: "envelope.badge.fill")
            .resizable()
        
            .frame(width: 150, height: 150, alignment: .center) .foregroundColor(Color.green)
            .scaleEffect(-1)
    }
}

struct ScalingDrawing_Previews: PreviewProvider {
    static var previews: some View {
        ScalingDrawing()
    }
}
