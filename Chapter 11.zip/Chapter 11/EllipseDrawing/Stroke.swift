//
//  Stroke.swift
//  EllipseDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct Stroke: View {
    var body: some View {
        Ellipse()
        .stroke(style: StrokeStyle(lineWidth: 7, dash: [CGFloat(10)]))
                   .foregroundColor(Color.orange)
                   .frame(width: 150, height: 50)
    }
}

struct Stroke_Previews: PreviewProvider {
    static var previews: some View {
        Stroke()
    }
}
