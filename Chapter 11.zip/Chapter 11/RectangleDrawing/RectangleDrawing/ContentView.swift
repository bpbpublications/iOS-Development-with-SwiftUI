//
//  ContentView.swift
//  RectangleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Rectangle()
                    .fill(Color.red)
                    .frame(width: 300, height: 200)
                    .border(Color.green, width: 6)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
