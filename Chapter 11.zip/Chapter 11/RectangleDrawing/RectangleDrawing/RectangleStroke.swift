//
//  RectangleStroke.swift
//  RectangleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct RectangleStroke: View {
    var body: some View {
        Rectangle()
            .stroke(style: StrokeStyle(lineWidth: 20,
                                       dash: [CGFloat(10), CGFloat(5), CGFloat(2)],
                                       dashPhase: CGFloat(10)))
            .fill(Color.red)
            .frame(width: 300, height: 200)
    }
}

struct RectangleStroke_Previews: PreviewProvider {
    static var previews: some View {
        RectangleStroke()
    }
}
