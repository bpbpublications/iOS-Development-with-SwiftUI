//
//  RoundedRectangleDrawing.swift
//  RectangleDrawing
//
//  Created by Laxit on 09/01/22.
//

import SwiftUI

struct RoundedRectangleDrawing: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 25, style: .circular)
                    .stroke(style: StrokeStyle(lineWidth: 20,
      
           dash: [CGFloat(10), CGFloat(5), CGFloat(2)],
                                   dashPhase: CGFloat(10)))
        .fill(Color.blue)
        .frame(width: 300, height: 200)
    }
    
}

struct RoundedRectangleDrawing_Previews: PreviewProvider {
    static var previews: some View {
        RoundedRectangleDrawing()
    }
}
