//
//  ContentView.swift
//  ScreenBlendMode
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            ZStack {
                RoundedRectangle(cornerRadius: 25, style: .circular)
                    .fill(Color.red)
                    .frame(width: 150 )
                    .offset(x: -60, y: -80)
                    .blendMode(.screen)
                RoundedRectangle(cornerRadius: 25, style: .circular)
                    .fill(Color.green)
                    .frame(width: 150 )
                    .offset(x: 60, y: -80)
                    .blendMode(.screen)
                RoundedRectangle(cornerRadius: 25, style: .circular)
                    .fill(Color.blue)
                    .frame(width: 200 )
                    .blendMode(.screen)
            }
            .frame(width: 300, height: 300)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
       // .background(Color.white)
        .background(Color.black)
        .edgesIgnoringSafeArea(.all)
    } }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
