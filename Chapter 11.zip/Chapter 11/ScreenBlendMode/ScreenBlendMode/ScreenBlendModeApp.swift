//
//  ScreenBlendModeApp.swift
//  ScreenBlendMode
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

@main
struct ScreenBlendModeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
