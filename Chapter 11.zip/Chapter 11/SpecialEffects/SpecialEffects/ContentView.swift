//
//  ContentView.swift
//  SpecialEffects
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Image("TajMahal")
            Rectangle()
                .fill(Color.red)
                //.blendMode(.multiply)
                .blendMode(.colorBurn)
                //.blendMode(.colorDodge)
                //.blendMode(.darken)
                //.blendMode(.difference)
        }
        .frame(width: 400, height: 500)
        .clipped()
}
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
