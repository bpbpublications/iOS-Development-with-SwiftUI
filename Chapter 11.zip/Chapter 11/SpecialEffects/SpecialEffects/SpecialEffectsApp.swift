//
//  SpecialEffectsApp.swift
//  SpecialEffects
//
//  Created by Laxit on 10/01/22.
//

import SwiftUI

@main
struct SpecialEffectsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
