//
//  ApiEndPoint.swift
//  NetworkingDemo
//
//  Created by Laxit on 11/07/21.
//

import Foundation
protocol APIBuilder
{
    var urlRequest :URLRequest{ get }
    var baseUrl: URL { get }
    var path: String{ get }
}

enum NewsAPI
{
    case getPeople
}

extension NewsAPI: APIBuilder {
    var urlRequest: URLRequest {
        return URLRequest(url: self.baseUrl.appendingPathComponent(path))
    }
    
    var path : String {
       return "/UnderstandingSwiftUI/News/people"
    }
    
    var baseUrl: URL{
        switch self{
        case .getPeople:
            return URL(string: "https://my-json-server.typicode.com/")!
        }
    }
    
}
