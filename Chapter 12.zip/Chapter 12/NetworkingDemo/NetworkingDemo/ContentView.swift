//
//  ContentView.swift
//  NetworkingDemo
//
//  Created by Laxit on 10/07/21.
//

import SwiftUI

@available(iOS 15.0, *)
struct ContentView : View {
    @StateObject var newsViewModel = NewsViewModel()
    var body: some View {
       ZStack{
        List(newsViewModel.articles) { article in
            VStack(alignment: .leading) {
                Text(article.title)
                    .foregroundColor(.blue)
                    .font(.headline)
                Text(article.description)
                    .font(.subheadline)
            }
        }
        if newsViewModel.isLoading {
          ProgressView("Wait..")
                .progressViewStyle(CircularProgressViewStyle(tint: .red))
                .scaleEffect(2)
                .foregroundColor(.green)
            }
        }
    }
}
@available(iOS 15.0, *)
struct DarkBlueShadowProgressViewStyle: ProgressViewStyle {
    func makeBody(configuration: Configuration) -> some View {
        ProgressView(configuration)
            .tint(.green)
            .shadow(color: Color.red,
                    radius: 4.0, x: 1.0, y: 2.0)
        
    }
}

@available(iOS 15.0, *)
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
