//
//  NetworkModel.swift
//  MVVMSwiftUI
//
//  Created by Mukesh Sharma on 08/06/20.
//  Copyright © 2020 Mukesh. All rights reserved.
//



import Combine
import Foundation


class NetworkManager {
  public static let shared = NetworkManager()
     func  getJSON(url: URL)->AnyPublisher<[NewsModel], APIError>{
        let request = URLRequest(url: url)
        let decoder = JSONDecoder()
         return URLSession.shared
            .dataTaskPublisher(for: request)
            .receive(on: DispatchQueue.main)
            .mapError { _ in .unknown }
            .flatMap { data, response -> AnyPublisher<[NewsModel], APIError> in
                if let response = response as? HTTPURLResponse {
                    if (200...299).contains(response.statusCode) {
                    return Just(data)
                        .decode(type: [NewsModel].self, decoder: decoder)
                        .mapError {_ in .decodingError}
                        .eraseToAnyPublisher()
                    } else {
                        return Fail(error: APIError.errorCode(response.statusCode))
                            .eraseToAnyPublisher()
                    }
                }
                  return Fail(error: APIError.unknown)
                        .eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()

        }
    }
 

