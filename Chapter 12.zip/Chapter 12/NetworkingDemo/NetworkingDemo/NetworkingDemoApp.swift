//
//  NetworkingDemoApp.swift
//  NetworkingDemo
//
//  Created by Laxit on 10/07/21.
//

import SwiftUI
@available(iOS 15.0, *)
@main
struct NetworkingDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
