//
//  NewsResponse.swift
//  MVVMSwiftUI
//
//  Created by Mukesh Sharma on 08/06/20.
//  Copyright © 2020 Mukesh. All rights reserved.
//

import Foundation

struct NewsModel: Codable {
    let userId: Int
    let id: Int?
    let title: String?
    let body: String?
}
