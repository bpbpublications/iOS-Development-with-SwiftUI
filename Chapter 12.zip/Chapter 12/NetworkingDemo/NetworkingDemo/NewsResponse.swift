//
//  NewsResponse.swift
//  MVVMSwiftUI
//
//  Created by Mukesh Sharma on 08/06/20.
//  Copyright © 2020 Mukesh. All rights reserved.
//

import Foundation

class NewsResponse: Identifiable,Codable {
    let post: NewsModel
    init(article: NewsModel) {
        self.post = article
    }
    var title: String {
        return post.title ?? ""
    }
    var description: String {
        return post.body ?? ""
    }
    
}
