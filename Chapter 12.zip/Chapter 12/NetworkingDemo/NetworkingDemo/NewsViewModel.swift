//
//  NewsViewModel.swift
//  MVVMSwiftUI
//
//  Created by Mukesh Sharma on 08/06/20.
//  Copyright © 2020 Mukesh. All rights reserved.
//

//import Foundation
import Combine
import SwiftUI

class NewsViewModel: ObservableObject {
    var cancellables = Set<AnyCancellable>()
    @Published var articles = [NewsResponse]()
    @Published var error = "Error"
    @Published var isLoading = false
    init() {
        getPosts()
    }
    private func getPosts() {
        guard let url = URL(string: "https://my-json-server.typicode.com/UnderstandingSwiftUI/News/people") else {
            self.isLoading = false
            self.error = "URL Not Valid"
            return
        }
        self.isLoading = true
        NetworkManager.shared.getJSON(url:url)
            .sink(receiveCompletion:{ taskCompletion in
                switch taskCompletion {
                case .finished:
                    return
                case .failure(let decodingError):
                    self.isLoading = false
                    self.error = decodingError.localizedDescription
                }
            }, receiveValue:{ newsContainer in
                self.isLoading = false
                self.articles = newsContainer.map(NewsResponse.init)
            }).store(in: &cancellables)
    }
}


