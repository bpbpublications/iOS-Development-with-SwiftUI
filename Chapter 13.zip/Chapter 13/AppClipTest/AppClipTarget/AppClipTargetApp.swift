//
//  AppClipTargetApp.swift
//  AppClipTarget
//
//  Created by Laxit on 24/10/21.
//

import SwiftUI

@main
struct AppClipTargetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
