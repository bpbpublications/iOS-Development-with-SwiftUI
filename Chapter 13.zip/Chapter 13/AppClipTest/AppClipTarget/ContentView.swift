//
//  ContentView.swift
//  AppClipTarget
//
//  Created by Laxit on 24/10/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        Text("Hello, world!..")
            .padding()
        Image("AppStore")

       Button("Test"){
          // Storage().test()
       }
       Button("Print"){
          // Storage().printData()
       }
      
       Button("Store"){
         //  Storage().storedata()
       }
       
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
