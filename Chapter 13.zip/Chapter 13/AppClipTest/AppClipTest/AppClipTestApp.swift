//
//  AppClipTestApp.swift
//  AppClipTest
//
//  Created by Laxit on 24/10/21.
//

import SwiftUI

@main
struct AppClipTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
