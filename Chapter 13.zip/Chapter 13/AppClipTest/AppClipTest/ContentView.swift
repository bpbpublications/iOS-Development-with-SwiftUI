//
//  ContentView.swift
//  AppClipTest
//
//  Created by Laxit on 24/10/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello, world!..")
                .padding()
            Image("AppStore")
            Button("Test"){
                Storage().test()
            }
            Button("Store"){
                Storage().storedata()
            }
            Button("Print"){
                Storage().printData()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
