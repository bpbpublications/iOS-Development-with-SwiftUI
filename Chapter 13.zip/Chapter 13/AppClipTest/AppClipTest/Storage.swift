//
//  Storage.swift
//  AppClipDemo.
//
//  Created by Laxit on 16/03/21.
//

import Foundation

class Storage{
    let sharedUserDefaults = UserDefaults(suiteName: "group.mukesh.AppClip11")
    func test(){
        
      
        print("Accessible everywhere")
    
    }
    func storedata(){
        if sharedUserDefaults == nil{
            print("App Group not found")
        }else{
        print("Data stored")
        sharedUserDefaults!.set("A sample string", forKey: "sharedText")
        }
        
    }
    func printData(){
        
        let migratedData = sharedUserDefaults!.string(forKey: "sharedText")
        if migratedData == nil {
            print("No data found")
        }else{
        print(migratedData as Any)
        }
    }
}
